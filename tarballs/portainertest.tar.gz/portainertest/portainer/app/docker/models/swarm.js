function SwarmViewModel(data) {
  this.Id = data.ID;
}
