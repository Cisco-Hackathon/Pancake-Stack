function AccessControlFormData() {
  this.AccessControlEnabled = true;
  this.Ownership = 'private';
  this.AuthorizedUsers = [];
  this.AuthorizedTeams = [];
}
