function TeamViewModel(data) {
  this.Id = data.Id;
  this.Name = data.Name;
  this.Checked = false;
}
